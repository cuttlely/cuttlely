# Version history

Cuttlely keeps every saved version of your flows here, one folder per flow.
It is a normal Git repo, managed by Cuttlely. Don't edit it while Cuttlely is running.
Secrets are never written here: credentials appear by name only.
